"""Main entry point for the arxiv-mcp-server package."""

from . import main

if __name__ == "__main__":
    main()
